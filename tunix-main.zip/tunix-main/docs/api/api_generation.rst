Generation
==========

.. currentmodule:: tunix

.. autosummary::

    Sampler
    CacheConfig

----

.. autoclass:: Sampler

----

.. autoclass:: CacheConfig

