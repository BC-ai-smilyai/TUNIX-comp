Distillation
============

.. currentmodule:: tunix

.. autosummary::

    DistillationTrainer
    DistillationTrainingConfig

----

.. autoclass:: DistillationTrainer

----

.. autoclass:: DistillationTrainingConfig
