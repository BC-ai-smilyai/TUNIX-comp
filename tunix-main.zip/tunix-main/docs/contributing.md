# How to Contribute

```{include} ../CONTRIBUTING.md
:start-line: 2
```
